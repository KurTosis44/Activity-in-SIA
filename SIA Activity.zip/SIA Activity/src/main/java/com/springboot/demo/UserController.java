package com.springboot.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
@RequestMapping("/api/v1/users")
public class UserController {

    @GetMapping
    public User getInfo() {
        
        return new User("Kurt Arron", "69", "IT");

    }
}
