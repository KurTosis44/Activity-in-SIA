package com.springboot.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

class User {
	private String Name;
	private String Age;
	private String Course;

	public User(String Name, String Age, String Course) {
		this.Name = Name;
		this.Age = Age;
		this.Course = Course;
	}

	public String getName() { return Name; }
	public String getAge() { return Age; }
	public String getCourse() { return Course; }
}

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

}
